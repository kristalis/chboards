import React from 'react'
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { NavigationContainer } from '@react-navigation/native'


import DairyScr from '../screens/Dairy'
 
const Stack = createNativeStackNavigator();

export default function Dairymenu() {
    return (
    <NavigationContainer independent= {true}>
        <Stack.Navigator>
            <Stack.Screen
            options = {{headerShown: false}}
            name = "DairyScr"
            component={DairyScr} 
            />
        </Stack.Navigator>
    </NavigationContainer>
    )
}
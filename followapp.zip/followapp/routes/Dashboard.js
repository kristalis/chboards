import React from 'react'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { NavigationContainer } from '@react-navigation/native'
 
import DairyScr from '../screens/Schedule'
import HelpScr from '../screens/Help'
import DairyMenuScr from '../routes/DairyMenu'
import { MaterialCommunityIcons } from '@expo/vector-icons';
import AppointmentScreen from '../screens/Appointment';
 

const Tab = createBottomTabNavigator();
 

export default function Dashboard() {
    return (
      <Tab.Navigator
        screenOptions={{
           unmountOnBlur: false,
            headerShown: false,
            "tabBarActiveTintColor": "red",
            "tabBarInactiveTintColor": "black",
            "tabBarLabelStyle": {
              "fontSize": 14
            },
            "tabBarStyle": [
              {
                "display": "flex"
              },
              null
            ]
          }}
        >
        <Tab.Screen 
         options={{
            tabBarLabel: 'FollowApp',
            unmountOnBlur: true,
            tabBarIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="phone" color={color} size={size} />
            ),
          }}
        name="Home" component={DashboardRoutes} />

        <Tab.Screen 
           options={{
            unmountOnBlur: false,
            tabBarLabel: 'Dairy',
            tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="calendar-search" color={color} size={size} />
            ),
        }}
        name="DairyMenu" component={DairyMenuScr} />

        <Tab.Screen 
        options={{
            tabBarLabel: 'Set schedules',
            tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="calendar-account" color={color} size={size} />
            ),
        }}
        name="DairyScr" component={DairyScr} />
        
        <Tab.Screen 
           options={{
            unmountOnBlur: true,
            tabBarLabel: 'Settings',
            tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="cog" color={color} size={size} />
            ),
        }}
        name="Help" component={HelpScr} />
      </Tab.Navigator>
      );
    }

    const Stack = createNativeStackNavigator();

    function DashboardRoutes() {
      return (
        <NavigationContainer independent= {true}>
          <Stack.Navigator>
            <Stack.Screen
            options = {{headerShown: false}}
            name = "AppointmentScreen"
            component={AppointmentScreen} 
            />
          </Stack.Navigator>
        </NavigationContainer>
      )
    }

import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from "./screens/HomeScreen";
import AppointmentScreen from "./routes/Dashboard";
import React, { useState } from "react";
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useFonts } from 'expo-font';
import AppLoading from 'expo-app-loading';




const Stack = createNativeStackNavigator();



export default function App() {

   
    const [loaded] = useFonts({
      Redressed:  require('./assets/fonts/Redressed-Regular.ttf'),
      Shizuru: require('./assets/fonts/Shizuru-Regular.ttf'),
       
  });
  
  if (!loaded) {
    return (
      <AppLoading
        startAsync={loaded}
        onFinish={() => loaded}
        onError={() => {}}
      />);
  }


    return (
    //you can return any component of your choice here
    <NavigationContainer>
           <Stack.Navigator initialRouteName="Homescreen">
 
             <Stack.Screen
              name="HomeScreen"
              component={HomeScreen}
             options={{
                 headerShown: false,
                 title: 'Follow App',
                 headerStyle: {
                 backgroundColor: '#00AD98', 
                },
                headerTintColor: '#fff',
                 headerTitleStyle: {
                  fontWeight: 'bold',
                 },
               }}
            />
            <Stack.Screen
             name="AppointmentScreen"
             component={AppointmentScreen}
             options = {{headerShown: false}}
           /> 
         </Stack.Navigator>
       </NavigationContainer>
    );

}


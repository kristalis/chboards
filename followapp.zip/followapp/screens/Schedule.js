import React, { useState, useEffect } from 'react'
import {ActivityIndicator, SafeAreaView, FlatList,  View, Text, TextInput, TouchableOpacity, Alert} from 'react-native'
import colors from '../const/Colors'
import styles from '../styles/index'
import * as Contacts from 'expo-contacts'
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { DatabaseConnection } from '../database/database-connection';
import DateTimePicker from '@react-native-community/datetimepicker';


export default function Schedule({navigation}) {
  useEffect(() => {
    const startLoading = navigation.addListener('focus', () => {
      setLoading(true);
      fetchData(); 
      setTimeout(() => {
      setLoading(false);
      }, 2000);
  });
  return startLoading;   
}, []);
  
  const db = DatabaseConnection.getConnection();
  const [loading, setLoading] = useState(true); 
  const [contacts, setContacts ] = useState([])
  const [dataBackUp, setDataBackUp] = useState([]);
  const [date, setDate] = useState(new Date());
  const [mode, setMode] = useState('date');
  const [show, setShow] = useState(false);

  const follow_user = (userName, userContact,userDate) => {
   
    if (!userName) {
      alert('No name');
      return;
    }
    if (!userContact) {
      alert('No contact nr');
      return;
    }
    if (!userDate) {
      alert('Set date');
      return;
    }

    db.transaction(function (tx) {
      tx.executeSql(
        'INSERT INTO table_followapp (user_name, user_contact, user_comment, user_called, call_date) VALUES (?,?,?,?,?)',
        [userName, userContact,'', 0, userDate],
        (tx, results) => { 
          if (results.rowsAffected > 0) {
           
            navigation.navigate('HomeScreen')
          } else alert('Appointment not set !!!');
        }
      );
    });
  };
 
   
  const fetchData = async () => {
    const { status } = await Contacts.requestPermissionsAsync();
    if (status === 'granted') {
      const { data } = await Contacts.getContactsAsync({
        fields: [Contacts.Fields.PhoneNumbers],
      });
      if (data.length > 0) {
        setContacts(data)
        setDataBackUp(data);
      } 
      
    }
   }
   
  const onChangeText = (text) => {
    let result = []
    result = dataBackUp.filter(item => (item.name.toLowerCase()).match(text.toLowerCase()));
    setContacts(result)
   
  }
  const onChange = (event, selectedDate) => {
    const currentDate = selectedDate || date;
    setShow(Platform.OS === 'ios');
    setDate(currentDate);
   
  };

  const showMode = (currentMode) => {
    setShow(true);
    setMode(currentMode);
  };
  
  const followappContacts = () => {
   if( date.toLocaleDateString() >= new Date().toLocaleDateString() )
      {
    if (selectedContacts == null || selectedContacts.length==0)
    {
        return alert('No Contact Selected !!!');
    }
    else {
     for (let i = 0; i < selectedContacts.length; i++) {
         let contact = contacts.find(o => o.lookupKey === selectedContacts[i]);
         follow_user(contact.name, contact.phoneNumbers[0].number, date.toLocaleDateString())
    }
  }
} else {
  return alert('Date is in the past!!!');
} 
}
 

  const showDatepicker = () => {
    showMode('date');
  };
  const [selectedContacts, setSelectedContacts] = useState([]);

  const renderItem = ({ item, index }) => {
   
    const { name, phoneNumbers, lookupKey } = item;
    const isSelected = selectedContacts.filter((i) => i === lookupKey).length > 0;
  return (
    
    <TouchableOpacity
        onPress={() => {
          if (isSelected) {
            setSelectedContacts((prev) => prev.filter((i) => i !== lookupKey));
          
          } else {
            setSelectedContacts(prev => [...prev, lookupKey])
          }
        }}
      >
        { phoneNumbers?
      <View style= {{...styles.contactList,  backgroundColor: isSelected ? 'black':colors.list}}>
      
          <View style={{  flex: 1,
          justifyContent: "center",
          paddingLeft: 5}}>
            <Text
              style={styles.customFont(14, isSelected ? colors.white : colors.black, 1.2)}
            > 
              {`${name}`}
            </Text>
            <Text
              style={styles.customFont(14, isSelected ? colors.white : colors.black, 1.2)}
            > 
            {phoneNumbers ? phoneNumbers[0].number : ''}
            </Text>
          </View>
          { isSelected ?<MaterialCommunityIcons name="checkbox-marked-circle-outline" size={24} color={isSelected ? colors.white : colors.black} />:<MaterialCommunityIcons name="checkbox-blank-circle-outline" size={24} color="black" />}
          
      </View>:null
  }

  </TouchableOpacity>
  )};
  
  return (
    <SafeAreaView style={styles.safeareaView}>
      <View style={styles.header}>
          <Text style={styles.customFont(20,colors.black)}>
            Set Call Appointments
          </Text>
          <Text style={styles.customFont(20,colors.black)}>
            { selectedContacts.length > 0 ? selectedContacts.length +' followAPP tobe Scheduled' : null }
          </Text>
      </View>
      <View style={styles.container}>

          { loading ? (  <ActivityIndicator
            //visibility of Overlay Loading Spinner
            visible={loading}
            //Text with the Spinner
            textContent={'Loading...'}
            //Text style of the Spinner Text
            textStyle={{color:"#000000"}}
            style={{backgroundColor: colors.white, flex:1, alignItems: 'center', justifyContent: 'center'}}
            size="large"
            color="#0000ff"
          />
        ) : (
         <>
          <View style={{ marginBottom:10, paddingHorizontal: 10, justifyContent: 'center',  height:27, borderWidth: 0.6 }}>
          <TextInput
            placeholder={'Search by name or phone number'}
            onChangeText={(text) => onChangeText(text)}
          />
        </View>
       
          <FlatList
            data={contacts}
            renderItem={renderItem}
            initialNumToRender={10} 
            removeClippedSubviews={true}
            keyExtractor={(item) => item?.lookupKey}
          ></FlatList>
          </> 
        )
      }
        <View style={{...styles.button(colors.btnColor),justifyContent:'center', marginTop:5}}>
          <TouchableOpacity onPress={showDatepicker} style={{ flexDirection:'row',  justifyContent: 'space-between'}}>
            <Text
              style={{...styles.customFont(14, colors.white, 1.2), paddingLeft:10}}
            >
              {date.toDateString()} 
            </Text>
            <MaterialCommunityIcons name="calendar" color={colors.primary} size={24} />
          </TouchableOpacity>
        </View>       
        {show && (
              <DateTimePicker
                testID="dateTimePicker"
                value={date}
                mode={mode}
                is24Hour={true}
                display="default"
                onChange={onChange}
              />
            )}
          <TouchableOpacity  onPress={followappContacts}>
            <View style={{...styles.button(colors.dark), marginTop:10, justifyContent:'center', alignContent:'center', height:55}}> 
              <Text style={{color:colors.white, textAlign:'center'}}>
                ADD TO SCHEDULES
              </Text>
            </View>
          </TouchableOpacity>
      </View>   
    </SafeAreaView>  
    )
  }
    

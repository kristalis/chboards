import React from 'react'
import { useState, useEffect } from 'react'
import { SafeAreaView, FlatList,  View, Text, Pressable, Modal, Alert, TextInput} from 'react-native'
import colors from '../const/Colors'
import styles from '../styles/index'
import { MaterialCommunityIcons } from '@expo/vector-icons';
import call from 'react-native-phone-call';
import { DatabaseConnection } from '../database/database-connection';
import MyImageButton from '../components/MyImageButton';
import FilterCallsButton from '../components/FilterCallsButton'

export default function Appointment({navigation}) {


  const db = DatabaseConnection.getConnection();
  const [data, setData] = useState([]);
  const [dataBackUp, setDataBackUp] = useState([]);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [modalVisible, setModalVisible] = useState(false);
  const [userData, setUserData]= useState([])
  const [userCalls, setUserCalls]= useState(true)

    useEffect(() => {
      fetchData(currentDate.toLocaleDateString());     
  }, [userData]);

    const fetchData = async (currDate) => {
    try {
      db.transaction((tx) => {
        tx.executeSql(
          `SELECT * FROM table_followapp WHERE call_date = '${currDate}'`,
          [],
          (tx, results) => {
            var temp = [];
            for (let i = 0; i < results.rows.length; ++i)
              temp.push(results.rows.item(i));
              setData(temp);
              setDataBackUp(temp);
          }
        );
      });
    } catch (ex) {
      console.log(ex);
    }
  };

  const updateUserNotes = (usercomment, dairyId) => {     
    db.transaction((tx) => {
      tx.executeSql(
        'UPDATE table_followapp set user_comment=? where dairy_id=?',
        [usercomment, dairyId],
        (tx, results) => {
          if (results.rowsAffected > 0) {
            setUserData({...userData, userComment: usercomment}) 
          } else  Alert.alert('Sorry notes did not update..., Try again');
        }
      );
    });
    setModalVisible(!modalVisible)
  };
  const updateUserCalled = (userCalled, phonenr, dairyId) => {     
    db.transaction((tx) => {
      tx.executeSql(
        'UPDATE table_followapp set user_called=? where dairy_id=?',
        [userCalled, dairyId],
        (tx, results) => {
          
          if (results.rowsAffected > 0) {
            triggerCall(phonenr)
          } else alert('Erro ao atualizar o usuário');
        }
      );
    });

  };
  const triggerCall = (phoneNumber) => {
    // if (phoneNumber.length != 11) {
    //   alert(phoneNumber+' does not look complete');
    //   return;
    // }
   // setModalVisible(!modalVisible)
    setUserData({...userData, called:true, nrcalled:phoneNumber})
    const args = {
      number: phoneNumber.toString(),
      prompt: true,
    };

    // Make a call
    call(args).catch(console.error);
 
   
  };
  const handleButtonPress = () => {
    setModalVisible(true)
  }
  const onChangeText = (text) => {
    setUserData({...userData, userComment:text})
  }

  function getChecked (value) {
    let result = []
    result = dataBackUp.filter(item => (item.user_called.toString()).match(value));
    setData(result)
    setUserCalls(value)
     
    }
  const renderItem = ({ item }) => (
  <View style= {{...styles.contactList }}>
      <Text
        style={styles.customFont(14, colors.black, 1.2)}
      >
       {item?.user_name}
      </Text>
      <View style={{  flexDirection: 'row',   justifyContent:'space-around'}}>
      <Pressable onPress={() => { 
        handleButtonPress()
        setUserData({...userData, dairyId:item.dairy_id,name:item.user_name, userComment: item.user_comment})
      }}
      >
        <MaterialCommunityIcons name="notebook" size={24} color={(item?.user_comment.length === 0 )?'blue':'green'} />
      </Pressable> 
      <Pressable onPress={() => { 
        setUserData({...userData, dairyId:item.dairy_id,name:item.user_name, phonenr: item.user_contact, userComment:item.user_comment})
        updateUserCalled(1,item.user_contact,item.dairy_id)
      }}
      >
        <MaterialCommunityIcons name="phone-classic" size={24} color={(item?.user_called === 1 )?'green':'red'} />
      </Pressable>
      </View>
  </View>
  );

  return (
    <SafeAreaView style={styles.safeareaView}>
      <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            Alert.alert("Modal has been closed.");
            setModalVisible(!modalVisible);
          }}
      >
      <View style={styles.centeredView}>
        <View style={styles.modalView}>
          <Text style={styles.modalText}>Notes for {userData.name}</Text>
          <TextInput
              multiline={true}
              numberOfLines={8}
              placeholder="Add some reminder notes about call if required..."
              style={{ flexDirection: 'row',borderWidth:1, borderColor:colors.dark, backgroundColor:colors.white, fontSize: 11, width: 280, padding:10, marginBottom: 20}}
              onChangeText={(text) => onChangeText(text)}
              value={userData.userComment}
             
          />
          <View style={{flexDirection:'row', justifyContent:'space-between'}}>
          <Pressable
              style={styles.button('red')}
              onPress={() => setModalVisible(!modalVisible)}
            >
              <Text>
                Cancel
              </Text>
            </Pressable>
            <Pressable style={styles.button('green')}
              onPress={() => updateUserNotes(userData.userComment,userData.dairyId)} 
            >
              <Text>Submit</Text>
            </Pressable>
        </View>
        </View>
      </View>
      </Modal>
      <View style={styles.header}>
        <Text style={styles.customFont(20,colors.black)}>
          Contacts to Call 
        </Text>       
        <View>
          <Text style={styles.customFont(20,colors.black)}
            >
            Today - {new Date().toDateString("en-GB")}
          </Text>
        </View>
        
      </View>
      { (data.length > 0 && data != null) || userCalls ?
      <View style={styles.container}>
          <FlatList
            data={data}
            renderItem={renderItem}
            keyExtractor={(item) => item?.dairy_id.toString()}
          ></FlatList>
          <View style={{flexDirection:'row', alignContent:'space-between', justifyContent:'center'}}>
            <FilterCallsButton
            getChecked={getChecked}
            />
          </View>
      </View> :
      <View style={{ flex: 1, justifyContent:'center', alignContent:'center' }}>
        <MyImageButton
          title={"NO SCHEDULED FOLLOWAPP\nSETUP YOUR FOLLOWAPP CALLS NOW"}
          btnColor='#2992C4'
          btnIcon="calendar"
        />
        
      </View>
 }  
    </SafeAreaView>  
    );
    }
    

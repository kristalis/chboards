import React, { useEffect } from 'react';
import { View,Text, SafeAreaView, Image } from 'react-native';
import MyImageButton from '../components/MyImageButton';
import {DatabaseConnection}  from '../database/database-connection';
import {DatabaseTable}  from '../database/database-connection';
import Styles from '../styles';
import Colors from '../const/Colors';




export default function HomeScreen ({ navigation }) {
   const db = DatabaseConnection.getConnection();
  

  useEffect(() => {
    DatabaseTable.createTable(db)
  }, []);

  return (
    <SafeAreaView style={{flex:1, backgroundColor:Colors.primary}}>
      
          <View style={{ flex: 2, justifyContent:'center', alignItems:'center'}}>
            <Image source={require('../assets/icon.png')} style={Styles.logo(256,256)}></Image>
            <Text style={{color:Colors.secondary, fontSize:36}}>followApp</Text>
          </View>
          <View style={{ flex: 1}}>
            <MyImageButton
              title="CHECKOUT FOLLOWAPPs FOR THE DAY"
              btnColor= {Colors.secondary}
              btnIcon="account-multiple-plus"
              customClick={() => navigation.navigate('AppointmentScreen')} 
            />
          </View>
     
    </SafeAreaView>
  );
};

import React from 'react'
import { useState, useEffect } from 'react'
import { SafeAreaView,Switch,  View, Text, TouchableOpacity} from 'react-native'
import Colors from '../const/Colors'
import styles from '../styles/index'
import { MaterialCommunityIcons} from '@expo/vector-icons'
import { DatabaseConnection } from '../database/database-connection';
import pushNotifications from '../utilities/pushnotification'



export default function Help({navigation}) {

  useEffect(()=>{
      fetchData()
  },[isShown])

  const db = DatabaseConnection.getConnection();
  const [data, setData] = useState([]);
  const [currentTime, setCurrentTime] = useState(new Date());
    // Show or Hide the purple box
    const [isShown, setIsShown] = useState(false);

    // This function will be triggered when the Switch changes
    const toggleTheBox = (value) => {
      setIsShown(value);
      !isShown? pushNotifications.subscribeNotification():pushNotifications.cancelAllNotification()
    };
    
  const fetchData = () => {
    try {
      db.transaction((tx) => {
        tx.executeSql(
          `SELECT * FROM table_users`,
          [],
          (tx, results) => {
            var temp = [];
            for (let i = 0; i < results.rows.length; ++i)
              temp.push(results.rows.item(i));
              temp[0].isSubscribed === 1 ? setIsShown(true) : setIsShown(false) 
          }
        );
      });
    } catch (ex) {
      console.log(ex);
    }
  };
    return (
      <SafeAreaView style={styles.safeareaView}>
      
        <View style={styles.header}>
          <Text style={styles.customFont(20,Colors.black)}>
            Features
          </Text>       
          <View>
            <Text style={styles.customFont(20,Colors.black)}
             >
              Today - {currentTime.toDateString()}
            </Text>
          </View>
        </View>
       
          <View style={{padding: 10}}>
            <View style={{flexDirection:'row',justifyContent: 'space-between'}}>
              <View style={{paddingTop: 14}}>
                <Text style={{fontWeight:'bold'}}>
                  Subscribe for Notification : 
                </Text>
              </View>
            
                <Switch
                    trackColor={{ true: "#f9b534", false: "#767577" }}
                    thumbColor={isShown ? "#9f4896" : "#ddd"}
                    ios_backgroundColor="#9f4896"
                    onValueChange={toggleTheBox}
                    value={isShown}
                    circleSize={30}
                />
               
 
            </View>
            <Text style={{paddingLeft: 5}}>
              -- To get daily reminders of your followApps, subscribe for notification alerts
            </Text>
          </View>
            <View style={styles.line(1,'red')}/>
      
         <View style={{padding: 10}}>
            <View style={{flexDirection:'row',justifyContent: 'space-between'}}>
              <Text style={{fontWeight:'bold'}}>
                Schedule followApp Calls : 
              </Text>
              <TouchableOpacity onPress={()=>navigation.navigate('DairyScr')} >
                <MaterialCommunityIcons name="chevron-right" size={36} color="black"/>
              </TouchableOpacity>
            </View>
            <Text style={{paddingLeft: 5}}>-- Go to Schedules screen
            </Text>
            <Text style={{paddingLeft: 5}}>-- Select contacts to call
            </Text>
            <Text style={{paddingLeft: 5}}>-- Select date to call
            </Text>
            <Text style={{paddingLeft: 5}}>-- Click on 'Add to Schedules' to set
            </Text>
         </View>
      
         <View style={styles.line(1,'red')}/>

         <View style={{padding: 10}}>
            <View style={{flexDirection:'row',justifyContent: 'space-between'}}>
              <Text style={{fontWeight:'bold'}}>
                Amend Diary : 
              </Text>
              <TouchableOpacity onPress={()=>navigation.navigate('DairyMenu')} >
                <MaterialCommunityIcons name="chevron-right" size={36} color="black"/>
              </TouchableOpacity>
            </View>
            <Text style={{paddingLeft: 5}}>
              -- Go to your diary to amend followApp's schedules or add notes to followApps
            </Text>
         </View>
      
         <View style={styles.line(1,'red')}/>
         <View style={{padding: 10}}>
            <View style={{flexDirection:'row',justifyContent: 'space-between'}}>
              <Text style={{fontWeight:'bold', color:'red'}}>
                FollowApp for the day : 
              </Text>
              <TouchableOpacity onPress={()=>navigation.navigate('Home')} >
                <MaterialCommunityIcons name="chevron-right" size={36} color="black"/>
              </TouchableOpacity>
            </View>
            <Text style={{paddingLeft: 5}}>
              -- Click FollowApp tab to see your calls set for the day
            </Text>
            <Text style={{paddingLeft: 5}}>
              -- Start calling 
            </Text>
         </View>
      
         <View style={styles.line(1,'red')}/>
      </SafeAreaView>  
      );
    }

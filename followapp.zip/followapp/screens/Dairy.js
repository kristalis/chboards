import React from 'react'
import { useState, useEffect } from 'react'
import {SafeAreaView, FlatList,  View, Text,TextInput, Modal, Pressable, Platform} from 'react-native'
import colors from '../const/Colors'
import styles from '../styles/index'
import { MaterialCommunityIcons, Entypo} from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';
import { DatabaseConnection } from '../database/database-connection';
import { ChangeFollowapp } from '../database/database-connection';
import DairyUpdate from '../components/DairyUpdate'

export default function Dairy({ navigation }) {
  const db = DatabaseConnection.getConnection();
  const [userData, setUserData]= useState([])
  const [data, setData] = useState([]);
  const [dataBackUp, setDataBackUp] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [date, setDate] = useState(new Date());
  const [userEdit, setUserEdit] = useState(false);
   
   useEffect(() => {
    fetchData(date.toLocaleDateString())   
}, [date]);

   const fetchData = (currDate) => {
    try {
      db.transaction((tx) => {
        tx.executeSql(
          `SELECT * FROM table_followapp WHERE call_date = '${currDate}'`,
          [],
          (tx, results) => {
             
            var temp = [];
            for (let i = 0; i < results.rows.length; ++i)
              temp.push(results.rows.item(i));
              setData(temp);
              setDataBackUp(temp);
          }
        );
      });
    } catch (ex) {
      console.log(ex);
    }
  };

  const onChangeText = (text) => {
    let result = []
    result = dataBackUp.filter(item => ((item.user_name.toLowerCase()).match(text.toLowerCase()) ||(item.user_contact.toLowerCase()).match(text.toLowerCase())));
    setData(result)
  }

  const handleButtonPress = (dairyId) => {
    setModalVisible(true)
  }

 
  const [mode, setMode] = useState('date');
  const [show, setShow] = useState(false);

  const onChange = (event, selectedDate) => {
    const currentDate = selectedDate || date;
    setShow(Platform.OS === 'ios');
    setDate(currentDate);
  };


  const showMode = (currentMode) => {
    setShow(true);
    setMode(currentMode);
  };

  const showDatepicker = () => {
    showMode('date');
  };


  const updateSchedule = (userDate,userNotes, dairyId) => {
  //  console.log(userNotes, userDate.toLocaleDateString())
      ChangeFollowapp.updateFollowapp(userDate.toLocaleDateString(),userNotes,dairyId,db)   
      setUserEdit(false)
      navigation.navigate('DairyScr')
  };

  const renderItem = ({ item }) => (
  <View style= {styles.contactList}>
    <Text
      style={styles.customFont(14, colors.black, 1.2)}
    >
       {item?.user_name}
    </Text>
    
    <View style={{  flexDirection: 'row',   justifyContent:'space-around'}}>
    <MaterialCommunityIcons name="phone" size={24} color={(item?.user_called === 1)?'green':'red'} />
    { date.toLocaleDateString() != new Date().toLocaleDateString() ?
    <Pressable onPress={() => { 
        setUserData({...userData, dairyId:item.dairy_id,name:item.user_name, phonenr: item.user_contact, user_notes: item.user_comment})
        setUserEdit(true)
      }}
      >
      <MaterialCommunityIcons name="calendar-edit" size={24} color="black" />
    </Pressable>
     : null
    }
    </View>
   
  </View>
  );

    return (
      <SafeAreaView style={styles.safeareaView}>
      {/* ...end of modal... */}
        <View style={styles.header}>
            <Text style={styles.customFont(20,colors.black)}>
              FollowApps' on {date.toDateString() }
            </Text>
        </View>

        <View style={styles.container}>
        <View style={{...styles.button(colors.btnColor),justifyContent:'center'}}>
          <Pressable onPress={showDatepicker} style={{ flexDirection:'row',  justifyContent: 'space-between'}}>
            <Text
              style={{...styles.customFont(14, colors.white, 1.2), paddingLeft:10}}
            >
              {date.toDateString()} 
            </Text>
            <MaterialCommunityIcons name="calendar" color={colors.primary} size={24} />
          </Pressable>
        </View>       
          
      {show && (
        <DateTimePicker
          testID="dateTimePicker"
          value={date}
          mode={mode}
          is24Hour={true}
          display="default"
          onChange={onChange}
        />
      )}
    
     { userEdit ?
      <DairyUpdate 
        username= {userData.name}
        phonenumber={userData.phonenr}
        notes={userData.user_notes}
        notesUpdate={(text) => setUserData({...userData,user_notes:text})}
        updateBtn={()=>updateSchedule(date,userData.user_notes,userData.dairyId)}
       />:
     <>
          <FlatList
            data={data}
            renderItem={renderItem}
            keyExtractor={(item) => item?.dairy_id.toString()}
          ></FlatList>
          <View style={{ marginBottom:10, paddingHorizontal: 10, justifyContent: 'center',  height:27, borderWidth: 0.6 }}>
            <TextInput
              placeholder={'Search by name or phone number'}
              onChangeText={(text) => onChangeText(text)}
            />
          </View>
          </>
      }
        </View>   
      </SafeAreaView>  
      
      );
    }
    

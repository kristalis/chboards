import * as SQLite from 'expo-sqlite';
import { Alert} from 'react-native'
 
export const DatabaseConnection = {
  getConnection: () => SQLite.openDatabase("database.db")
};

export const DatabaseTable = {
  createTable: (db) => {
    db.transaction(function (txn) {
      txn.executeSql(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='table_followapp'",
        [],
        function (tx, res) {
          if (res.rows.length == 0) {
            txn.executeSql('DROP TABLE IF EXISTS table_followapp', []);
            txn.executeSql('DROP TABLE IF EXISTS table_users', []);
            txn.executeSql(
              'CREATE TABLE IF NOT EXISTS table_followapp(dairy_id INTEGER PRIMARY KEY AUTOINCREMENT, user_name VARCHAR(255), user_contact VARCHAR(11), user_comment TEXT, user_called BOOLEAN, call_date DATE)',
              []
            );
            txn.executeSql(
              'CREATE TABLE IF NOT EXISTS table_users(user_id INTEGER PRIMARY KEY AUTOINCREMENT, push_token VARCHAR(255), token_id VARCHAR(255), isSubscribed  BOOLEAN)',
              []
            );
            txn.executeSql(
              'INSERT INTO table_users (push_token, token_id, isSubscribed) VALUES (?,?,?)',
              ['ptoken','tokenid',false]
            );
          }
        }
      );
    });
  }
};

export const UserNotification = { 
notificationSubscribed : (status,db) => {
  try {
    db.transaction((tx) => {
      tx.executeSql(
        'UPDATE table_users set isSubscribed=? where user_id=1',
        [status],
        (tx, results) => {
          if (results.rowsAffected > 0) {
 
          } else  console.log('Sorry no update..., Try again');
        }
      );
    });
  } catch (ex) {
    console.log(ex);
  }
}
}

export const ChangeFollowapp = {
  updateFollowapp: (userDate, userNotes,dairyId, db) => { 
  db.transaction((tx) => {
    tx.executeSql(
      'UPDATE table_followapp set call_date=?, user_comment=? where dairy_id=?',
      [userDate,userNotes, dairyId],
      (tx, results) => {
        if (results.rowsAffected > 0) {
         
        } else  Alert.alert('Sorry followApps did not update..., Try again');
      }
    );
  });
}
}

export const UserNotes = {
 updateUserNotes: (usercomment, dairyId,db) => {     
  db.transaction((tx) => {
    tx.executeSql(
      'UPDATE table_followapp set user_comment=? where dairy_id=?',
      [usercomment, dairyId],
      (tx, results) => {
        if (results.rowsAffected > 0) {
          setUserData({...userData, userComment: usercomment}) 
        } else  Alert.alert('Sorry notes did not update..., Try again');
      }
    );
  })
}
}

export const UserToken = {
  
  addUserToken: (pushToken,db) => {  
   db.transaction((tx) => {
     tx.executeSql(
       'INSERT INTO table_users (push_token, token_id, isSubscribed) VALUES (?,?,?)',
       [pushToken, 'tokenId', true],
       (tx, results) => {
         if (results.rowsAffected > 0) {
            
         } else  Alert.alert('Sorry subscription failed');
       }
     );
   })
 }
 }
import React from 'react'
import { Text, TextInput } from 'react-native'
import Colors from '../const/Colors'
import Styles from '../styles/index'
import MyImageButton from '../components/MyImageButton';

const DairyUpdate = (props) => {

    return (
        <>
          <Text style={{paddingLeft:5, paddingTop:10}}>Name</Text> 
          <TextInput
            placeholder={props.username}
            style={{...Styles.input,  backgroundColor:Colors.light}}
            editable={false}
          />
           <Text style={{paddingLeft:5, paddingTop:10}}>Contact Nr.</Text> 
           <TextInput
            placeholder={props.phonenumber}
            style={{...Styles.input,  backgroundColor:Colors.light}}
            editable={false}
          />
           <Text style={{paddingLeft:5, paddingTop:10}}>Notes</Text> 
          <TextInput
              multiline={true}
              numberOfLines={8}
              placeholder="Add some reminder notes about call if required..."
              style={{ borderWidth:1, borderColor:Colors.dark, marginLeft:5, marginRight:5,marginBottom: 15, paddingLeft:20}}
              value={props.notes}
              onChangeText = {props.notesUpdate}
          />

          <MyImageButton
              title="UPDATE CALL DATE"
              btnColor= {Colors.secondary}
              btnIcon="update"
              customClick={props.updateBtn} 
          />
       </>
      )
};   
export default DairyUpdate;
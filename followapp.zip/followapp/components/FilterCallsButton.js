import React from 'react';
import RadioGroup,{Radio} from "react-native-radio-input";

const FilterCallsButton = (props) => {

  return (
         <RadioGroup 
            getChecked={props.getChecked}
            RadioGroupStyle={{flexDirection: "row" }}
         >
            <Radio 
                label={"Calls Made"} 
                value={"1"} 
            />
            <Radio 
                label={"Calls to Make"} 
                value={"0"} 
            />
        </RadioGroup>
  );
};  




export default FilterCallsButton;
import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';
import { DatabaseConnection } from '../database/database-connection';
import { UserNotification } from '../database/database-connection'

 Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: false,
    }),
  });
  
const db = DatabaseConnection.getConnection();
const schedule = new Date();  
    


class pushnotification {
 
    subscribeNotification = async () => {
        let token;
        if (Device.isDevice) {
          const { status: existingStatus } = await Notifications.getPermissionsAsync();
          let finalStatus = existingStatus;
          if (existingStatus !== 'granted') {
            const { status } = await Notifications.requestPermissionsAsync();
            finalStatus = status;
          }
          if (finalStatus !== 'granted') {
            alert('Failed to get push token for push notification!');
            return;
          }
          token = (await Notifications.getExpoPushTokenAsync()).data;
          UserNotification.notificationSubscribed(true,db)
          this.scheduleNotification()
        } else {
          alert('Must use physical device for Push Notifications');
        }
      
        if (Platform.OS === 'android') {
          Notifications.setNotificationChannelAsync('default', {
            name: 'default',
            importance: Notifications.AndroidImportance.MAX,
            vibrationPattern: [0, 250, 250, 250],
            lightColor: '#FF231F7C',
          });
        }
      
        return token;
      }


      scheduleNotification = async () => {
        schedule.setHours(7);
        schedule.setMinutes(45);
        let notificationId = await Notifications.scheduleNotificationAsync({
          content:{
            title: "Blessed One",
            body: "A Dear Soul needs your FollowApp call today",
          },
          trigger:{
         //   hour: 7, minute: 45, 
           // repeats: true,
           seconds: 10
          }
        });
      };

    cancelNotification = async (notificationId) => {
        await Notifications.cancelScheduledNotificationAsync(notificationId);
    }

    cancelAllNotification = async () => {
        await  Notifications.cancelAllScheduledNotificationsAsync();
        UserNotification.notificationSubscribed(false,db)
    }
}

const pushNotifications = new pushnotification();
export default pushNotifications
const Colors = {
    black: '#000',
    dark: '#404041',
    light: '#f6f2ef',
    white: '#fff',
    primary:'#f9b534',
    secondary:'#9f4896',
    playing: '#e3d9d4',
    active: '#e12207',
    list: '#f6f2f0',
    text: '#262626',
    overrideTitle:'#bd4343',
    overrideBody: '#d44c4c',
    onDemand: '#f0f0f0',
    onDemandText: '#d4cfcf',
    bottomTab: '#9f9f9f',
    modalBg: '#00000099',
    spinner: '#0000ff',
    dropdownBg: '#EFEFEF',
    dropdownBottom: '#C5C5C5',
    call:'#2196F3',
    btnColor:'#2992C4'
};

export default Colors;
import {StyleSheet, StatusBar, Platform} from 'react-native';
import colors from '../const/Colors';
 
const Styles = StyleSheet.create({

    logo: (imgW,imgH) =>({
      width: imgW,
      height: imgH,
    }),

    customBtn: (height, color) => ({
        height: height,
        backgroundColor: color,
        justifyContent: 'center',
        alignItems: 'center',
    }),
    /** fonts */
    customFont: (size, color, spacing) => ({
        fontSize: size,
        color: color,
        letterSpacing: spacing
    }),
    line: (thickness,color) => ({
      height: thickness,
      elevation: 2,
      backgroundColor: color,
      marginTop:5,
      marginBottom:5
    }),
/** alignment */    
    center: {
        alignItems: "center",
        justifyContent: "center",
    },
 
    safeareaView: {
        flex: 1,
        backgroundColor: colors.white,
      
    },
    container: {
        flex: 1,
        paddingLeft:15,
        paddingRight:15,
        paddingTop:10,
        paddingBottom:5
    },
    header: {
        alignItems: 'center',
        alignContent: 'center',
        paddingTop: Platform.OS === 'android' ?  StatusBar.currentHeight+20 : 20,
        backgroundColor:colors.primary,
        paddingBottom:15,
    },
    contactList: {
        flex: 1,
        flexDirection: 'row',
        justifyContent:'space-between',
        fontSize: 14,
        backgroundColor:colors.list,
        color: colors.black,
        paddingLeft: 20,
        paddingBottom:10,
        paddingTop:10,
        paddingRight:10,
        marginBottom: 5,
    },
    appointment: {
        flex: 1,
        flexDirection: 'row',
        fontSize: 14,
        backgroundColor:colors.white,
        color: colors.black,
        paddingLeft: 20,
        paddingBottom:10,
        paddingTop:10,
        paddingRight:10,
        marginBottom: 5,
    },
    centeredView: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        marginTop: 22
      },
      modalView: {
        width:300,
        margin: 20,
        backgroundColor: colors.primary,
        borderRadius: 20,
        padding: 25,
        alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
          width: 0,
          height: 2
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5
      },
      button: (color) => ({
        borderRadius: 20,
        padding: 10,
        elevation: 2,
        backgroundColor: color,
        borderRadius: 7
      }),
    
      textStyle: {
        color: "white",
        fontWeight: "bold",
        textAlign: "center"
      },
      modalText: {
        marginBottom: 15,
        textAlign: "center"
      }, 
      title: {
        textAlign: 'left',
        fontSize: 20,
        fontWeight: 'bold',
      },
      datePickerStyle: {
        width: 230,
      },
      text: {
        textAlign: 'left',
        width: 230,
        fontSize: 16,
        color : "#000"
      }, 
     
        dateIcon: {
          position: 'absolute',
          right: -5,
          top: 4,
          marginLeft: 0,
        },
        dateInput: {
          borderColor : "gray",
          alignItems: "flex-start",
          borderWidth: 0,
          borderBottomWidth: 1,
        },
        placeholderText: {
          fontSize: 17,
          color: "gray"
        },
        dateText: {
          fontSize: 17,
        },
        inputWrapper: {
          backgroundColor: colors.white,
          borderBottomWidth: 1,
          borderColor: colors.light,
          borderBottomWidth: 0.5,
          flex: 1,
          flexDirection: 'row',
          fontSize: 14,
          alignItems: 'center',
          alignContent: 'center',
      },
     
      datePickerStyle: {
        width: 230,
      },
      placeholder: {
        width: 25,
        height: 25,
        borderRadius: 30,
        overflow: "hidden",
        backgroundColor: "#d9d9d9",
        alignItems: "center",
        justifyContent: "center",
      },
      imgCon: {},
      input: {
        height: 40,
        margin: 5,
        paddingLeft:20,
        borderBottomWidth: 1,
      },
})

export default Styles;